#pragma once

#define WITH_OPENCV_DEBUG 0
#define WITH_ENCRYPT_MODEL 0