# EasyPlot
This repository contains matlab files for plotting precision curves and success rate curves for tracking algorithms. 
